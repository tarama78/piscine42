/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   serge.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/27 17:15:00 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/27 18:02:07 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SERGE_H
# define SERGE_H

# include <stdlib.h>

# define ABS(x) (x < 0) ? -x : x

void		ft_putstr_fd(int fd, char *str, int newline);
int			ft_strlen(char *str);
char		*ft_strncat(char *dest, char *src, int nb);
int			ft_atoi(char *str);
size_t		get_fd_content(int fd, char **buf);
int			ft_tej_moins_moins(char **av, int *first_arg, int *leplus);
void		ft_error(void);
void		ft_print_name(char *str, int newline);
int			ft_read_file(char *file, int nb_oct, int on_aff_le_nom[2],
						int leplus);

#endif
