/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/25 09:45:07 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/27 18:02:08 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "serge.h"
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>

int		ft_tej_moins_moins(char **av, int *first_arg, int *leplus)
{
	int		ret;

	ret = 0;
	*leplus = 0;
	if (av[1][0] == '-' && av[1][1] == 'c')
	{
		if (av[1][2] == '\0')
		{
			*first_arg = 3;
			if (av[2][0] == '+')
				*leplus = 1;
			ret = ABS(ft_atoi(av[2]));
		}
		else
		{
			*first_arg = 2;
			if (av[1][2] == '+')
				*leplus = 1;
			ret = ABS(ft_atoi(&(av[1][2])));
		}
	}
	else
		return (-1);
	return (ret);
}

void	ft_error(void)
{
	if (errno == EACCES)
		ft_putstr_fd(STDERR_FILENO, ": Permission denied", 1);
	else if (errno == EFBIG)
		ft_putstr_fd(STDERR_FILENO, ": File too large", 1);
	else if (errno == ENAMETOOLONG)
		ft_putstr_fd(STDERR_FILENO, ": File name too long", 1);
	else
		ft_putstr_fd(STDERR_FILENO, ": No such file or directory", 1);
}

void	ft_print_name(char *str, int newline)
{
	if (newline == 0)
		ft_putstr_fd(STDOUT_FILENO, "", 1);
	ft_putstr_fd(STDOUT_FILENO, "==> ", 0);
	ft_putstr_fd(STDOUT_FILENO, str, 0);
	ft_putstr_fd(STDOUT_FILENO, " <==", 1);
}

int		ft_read_file(char *file, int nb_oct, int on_aff_le_nom[2], int leplus)
{
	int		fd;
	int		size;
	char	*str;

	if ((fd = open(file, O_RDONLY)) == -1)
	{
		ft_putstr_fd(STDERR_FILENO, "tail: ", 0);
		ft_putstr_fd(STDERR_FILENO, file, 0);
		ft_error();
		return (1);
	}
	if (open(file, O_DIRECTORY) != -1)
	{
		ft_print_name(file, on_aff_le_nom[1]);
		return (0);
	}
	size = get_fd_content(fd, &str);
	if (on_aff_le_nom[0])
		ft_print_name(file, on_aff_le_nom[1]);
	str = (leplus == 1) ? str + nb_oct : str + size - nb_oct;
	ft_putstr_fd(STDOUT_FILENO, str, 0);
	if (close(fd) == -1)
		return (0);
	return (0);
}

int		main(int ac, char **av)
{
	int		i;
	int		nb_oct;
	int		leplus;
	int		first_arg;
	int		on_aff_le_nom[2];

	on_aff_le_nom[1] = 1;
	if (ac == 1)
		return (1);
	nb_oct = ft_tej_moins_moins(av, &first_arg, &leplus);
	if (nb_oct == -1)
		return (1);
	i = first_arg - 1;
	while (++i < ac)
	{
		on_aff_le_nom[0] = (ac - first_arg >= 2) ? 1 : 0;
		on_aff_le_nom[1] = ft_read_file(av[i], nb_oct, on_aff_le_nom, leplus);
	}
	return (0);
}
