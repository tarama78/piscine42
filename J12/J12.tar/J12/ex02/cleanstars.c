/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cleanstars.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/27 17:16:00 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/27 17:43:12 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "serge.h"
#include <unistd.h>
#include <stdlib.h>

void		ft_putstr_fd(int fd, char *str, int newline)
{
	while (*str)
		write(fd, str++, 1);
	while (newline--)
		write(fd, "\n", 1);
}

int			ft_strlen(char *str)
{
	int		size;

	size = -1;
	while (str[++size] != '\0')
		;
	return (size);
}

char		*ft_strncat(char *dest, char *src, int nb)
{
	int		i;
	int		j;
	int		lenght_dest;

	j = 0;
	lenght_dest = ft_strlen(dest);
	i = lenght_dest;
	while (i < lenght_dest + nb && src[j] != '\0')
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}

int			ft_atoi(char *str)
{
	int				neg;
	unsigned int	result;

	while (*str == '\n' || *str == '\t' || *str == '\v' || *str == '\f'
			|| *str == '\r' || *str == ' ' || *str == '\0')
		str++;
	if (*str == '\0')
		return (0);
	neg = 0;
	if ((*str == '+') && *(str + 1) >= '0' && *(str + 1) <= '9')
		neg = 0;
	else if (*str >= '0' && *str <= '9')
	{
		str--;
		neg = 0;
	}
	else if ((*str == '-') && *(str + 1) >= '0' && *(str + 1) <= '9')
		neg = 1;
	else
		return (0);
	result = 0;
	while (*(++str) >= '0' && *str <= '9')
		result = result * 10 + *str - '0';
	return (neg == 0) ? result : -result;
}

size_t		get_fd_content(int fd, char **buf)
{
	char		tmp[65536 + 1];
	ssize_t		ret_read;
	size_t		size_file;
	char		*ptr_tmp;

	*buf = NULL;
	size_file = 0;
	while ((ret_read = read(fd, tmp, sizeof(tmp) - 1)) > 0)
	{
		tmp[ret_read] = '\0';
		size_file += ret_read;
		ptr_tmp = *buf;
		if (!(*buf = malloc(size_file + 1)))
			return (0);
		(*buf)[0] = '\0';
		if (ptr_tmp == NULL)
			ft_strncat(*buf, tmp, size_file);
		else
		{
			ft_strncat(*buf, ptr_tmp, size_file);
			ft_strncat(*buf, tmp, size_file - ft_strlen(*buf));
			free(ptr_tmp);
		}
	}
	return (size_file);
}
