/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/21 14:59:30 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/27 14:43:25 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#define BUF_SIZE 10

void	ft_putstr_fd(int fd, char *str, int newline)
{
	while (*str)
		write(fd, str++, 1);
	while (newline--)
		write(fd, "\n", 1);
}

int		main(int ac, char **av)
{
	int		fd;
	char	str[BUF_SIZE + 1];
	int		size;

	if (ac == 1)
		ft_putstr_fd(STDERR_FILENO, "File name missing.", 1);
	else if (ac > 2)
		ft_putstr_fd(STDERR_FILENO, "Too many arguments.", 1);
	else
	{
		if ((fd = open(av[1], O_RDONLY)) == -1)
			return (1);
		str[0] = '\0';
		while ((size = read(fd, str, BUF_SIZE)) != 0)
		{
			str[size] = '\0';
			ft_putstr_fd(STDOUT_FILENO, str, 0);
		}
		if (close(fd) == -1)
			return (1);
	}
	return (0);
}
