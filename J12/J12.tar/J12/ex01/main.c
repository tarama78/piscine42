/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/24 19:51:15 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/27 14:42:04 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>

#define BUF_SIZE 32768

void	ft_putstr_fd(int fd, char *str, int newline)
{
	while (*str)
		write(fd, str++, 1);
	while (newline--)
		write(fd, "\n", 1);
}

void	ft_read_input(void)
{
	int		size;
	char	str[BUF_SIZE + 1];

	str[0] = '\0';
	while ((size = read(STDIN_FILENO, str, BUF_SIZE)) != 0)
	{
		str[size] = '\0';
		ft_putstr_fd(STDOUT_FILENO, str, 0);
	}
}

void	ft_error(void)
{
	if (errno == EACCES)
		ft_putstr_fd(STDERR_FILENO, ": Permission denied", 1);
	else if (errno == EFBIG)
		ft_putstr_fd(STDERR_FILENO, ": File too large", 1);
	else if (errno == ENAMETOOLONG)
		ft_putstr_fd(STDERR_FILENO, ": File name too long", 1);
	else
		ft_putstr_fd(STDERR_FILENO, ": No such file or directory", 1);
}

void	ft_read_file(char *file)
{
	int		fd;
	int		size;
	char	str[BUF_SIZE + 1];

	if ((fd = open(file, O_RDONLY)) == -1)
	{
		ft_putstr_fd(STDERR_FILENO, "cat: ", 0);
		ft_putstr_fd(STDERR_FILENO, file, 0);
		ft_error();
		return ;
	}
	if (open(file, O_DIRECTORY) != -1)
	{
		ft_putstr_fd(STDERR_FILENO, "cat: ", 0);
		ft_putstr_fd(STDERR_FILENO, file, 0);
		ft_putstr_fd(STDERR_FILENO, ": Is a directory", 1);
		return ;
	}
	while ((size = read(fd, str, BUF_SIZE)) != 0)
	{
		str[size] = '\0';
		ft_putstr_fd(STDOUT_FILENO, str, 0);
	}
	if (close(fd) == -1)
		return ;
}

int		main(int ac, char **av)
{
	int		i;

	if (ac == 1)
		ft_read_input();
	else
	{
		i = 0;
		while (++i < ac)
			ft_read_file(av[i]);
	}
	return (0);
}
