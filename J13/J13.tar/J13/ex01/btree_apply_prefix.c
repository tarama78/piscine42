/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_apply_prefix.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/26 11:17:54 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/26 13:06:47 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_apply_prefix(t_btree *root, void (*applyf)(void*))
{
	if (root)
	{
		applyf(root->item);
		if (root->left != 0)
			btree_apply_prefix(root, applyf);
		if (root->right != 0)
			btree_apply_prefix(root, applyf);
	}
}
