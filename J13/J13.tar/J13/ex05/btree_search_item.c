/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_search_item.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/26 12:53:09 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/26 13:06:46 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	*btree_search_item(t_btree *root, void *data_ref,
		int (*cmpf)(void *, void *))
{
	void	*ret;

	ret = 0;
	if (root)
	{
		if (cmpf(root->item, data_ref) > 0)
			ret = btree_search_item(root->left, data_ref, cmpf);
		else if (cmpf(root->item, data_ref) == 0)
			ret = root->item;
		else
			ret = btree_search_item(root->right, data_ref, cmpf);
	}
	return (ret);
}
