/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_create_node.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/26 11:06:49 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/26 13:06:46 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdlib.h>

t_btree		*btree_create_node(void *item)
{
	t_btree	*tree;

	if (!(tree = malloc(sizeof(*tree))))
		return (0);
	tree->left = 0;
	tree->right = 0;
	tree->item = item;
	return (tree);
}
