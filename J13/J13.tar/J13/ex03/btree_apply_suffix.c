/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_apply_suffix.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tnicolas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/26 11:46:43 by tnicolas          #+#    #+#             */
/*   Updated: 2017/07/26 12:27:05 by tnicolas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_apply_suffix(t_btree *root, void (*applyf)(void*))
{
	if (root)
	{
		if (root->left != 0)
			btree_apply_suffix(root, applyf);
		if (root->right != 0)
			btree_apply_suffix(root, applyf);
		applyf(root->item);
	}
}
